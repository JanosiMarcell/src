import React from 'react'

export default function CreateFilm() {
  return (
    <div>CreateFilm</div>
  )
}
