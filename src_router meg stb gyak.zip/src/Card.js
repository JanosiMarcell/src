import React from 'react'
import './Card.css'
export default function Card(props) {

    function Delete(Id){
        fetch("https://film.kando-dev.eu/film/"+Id, {method: "DELETE"})
        .then(function(response){
            console.log(response)
            alert("Sikeres törlés!")
            props.Get()
        })
        .catch(function(error){
            console.error(error);
            alert("Sikertelen törlés!")
        })
    }




  return (
    /* From Uiverse.io by 0xnihilism */ 
<div className="card">
  <div className="banner">
  <span className="banner-text">Értékelés</span>
<span className="banner-text">{props.ertekeles}</span>
  </div>
  <img src={'https://picsum.photos/200/300'} alt='sigma'></img>
  <span className="card__title">{props.nev}</span>
    
  <p className="card__subtitle">Kiadás Éve: {props.kiadaseve}</p>
  <p className="card__subtitle">Id: {props.Id}</p>

  <form className="card__form">
    <button onClick={function(){
        if (window.confirm("Biztosan törlöd?")){
            Delete(props.Id)
        }
    }} className="sign-up">Törlés</button>
  </form>
</div>


  )
}
