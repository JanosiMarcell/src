
//importok

import { Route, Routes } from "react-router-dom"
import ListFilms from "./ListFilms"
import Nav from "./Nav"
import CreateFilm from "./CreateFilm"




//fő function
export default function App() {

  return (
    <div>
      <Nav/>
      <Routes>
        <Route path = "/" element={<ListFilms/>}/>
        <Route path = "/ujfilm" element={<CreateFilm/>}/>

      </Routes>




    </div>
  )
}