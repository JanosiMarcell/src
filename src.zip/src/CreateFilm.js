import React from 'react'
import { useNavigate } from "react-router-dom";



export default function CreateFilm() {
  
  const navigate = useNavigate();
  
function Post(){


  let filmData ={
    nev :document.getElementById("nev").value,
    kiadaseve:Number(document.getElementById("kiadaseve").value),
    ertekeles:Number(document.getElementById("ertekeles").value),
    kepneve:document.getElementById("kepneve").value,
  }
  fetch("https://film.kando-dev.eu/film",{
    method: "POST",
    body: JSON.stringify(filmData),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(function(){
    navigate("/")
  })
 


}






  return (
    <div>
      <form onSubmit={function(event){
        event.preventDefault()
        Post()
      }}>
        <label>Add meg a film címét</label>
        <input type='text' id='nev'  required></input>
        <label>Értékelés: </label>
        <input type='number' id='ertekeles' required min={1} max={5}></input>
        <label>Kiadás éve</label>
        <input type='number' min="1870" max="2024" id='kiadaseve' required></input>
        <label>Film képe:</label>
        <input type='text' id='kepneve' required></input>

        <input type='submit' id='küldes'></input>
      </form>
    </div>
  )
}
