import React from 'react'
import './Card.css'
export default function Card(props) {

    function Delete(id){
        fetch("https://film.kando-dev.eu/film/"+id, {method: "DELETE"})
        .then(function(response){
            console.log(response)
            alert("Sikeres törlés!")
            props.Get()
        })
        .catch(function(error){
            console.error(error);
            alert("Sikertelen törlés!")
        })
    }




  return (
    /* From Uiverse.io by 0xnihilism */ 
<div className="card">
  <div className="banner">
  <span className="banner-text">Értékelés</span>
<span className="banner-text">{props.ertekeles}</span>
  </div>
  <img src={props.kep} alt='sigma'></img>
  <span className="card__title">{props.Nev}</span>
    
  <p className="card__subtitle">Kiadás Éve: {props.kiadaseve}</p>
  <p className="card__subtitle">id: {props.id}</p>

  <form className="card__form">
    <button onClick={function(){
        if (window.confirm("Biztosan törlöd?")){
            Delete(props.id)
        }
    }} className="sign-up">Törlés</button>
  </form>
</div>


  )
}
