import React from 'react'
import { useEffect, useState } from "react"
import Card from "./Card"

export default function ListFilms() {
    //useState változók (+egyéb)

const [database, setdatabase] = useState([])


//useEffect
// [] - egyszer fut le csak, oldalbetöltéskor

useEffect(() => {

  Get()


},[])

//függvénydefiníciók

function Get(){
    fetch("https://film.kando-dev.eu/film")
    .then(response => response.json())
    .then(data => {
      console.log(data)
      setdatabase(data)
    })
} 
  return (
    <div>
      {
      database.map(function(film){
        return <Card Get={Get} Nev={film.nev} kep ={film.kepneve} ertekeles ={film.ertekeles} kiadaseve ={film.kiadasEve} id={film.id}  />
      })
      }
    </div>
  )
}
